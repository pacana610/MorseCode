#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <Windows.h>

int signos;
int frecuencia;
int duracion;
int esRaya;


FILE* fichero;
void iniciaReproduccion()
{
	fichero = fopen("morse.txt", "rt");
    signos = 0;
}

int reproduceSigno()
{
	
	
	fscanf(fichero, "f:%d d:%d\n", &frecuencia, &duracion);
	
    esRaya = 0;

    if(frecuencia == 1000 && duracion == 1000)
    {
        printf("-");
        Beep(frecuencia, duracion);
    }
    else
    {
        printf(".");
        Beep(frecuencia, duracion);
    }
    
    
    
    signos = signos + 1;
    
    if(signos > 10)
    {
        printf("\n");
        return 1;
    }
    else { return 0; }
	
}

void finalizaReproduccion()
{
    fclose(fichero);
	
}

void iniciaGrabacion()
{
	fichero = fopen("morse.txt","wt");
	signos = 0;
}

int reproduceGrabacion()
{
	
	printf("Punto o raya?\n");
	printf("Raya, frecuencia = 1000ms duracion = 1000ms\n");
	printf("Punto, frecuencia = 1000ms duracion = 500ms\n");
	printf("Frecuencia?\n");
	scanf("%d", &frecuencia);
	
	printf("Duracion?\n");
	scanf("%d", &duracion);
	
	esRaya = 0;
	
	if(frecuencia == 1000 && duracion == 1000)
    {
        printf("-");
        Beep(frecuencia, duracion);
    }
    else
    {
        printf(".");
        Beep(frecuencia, duracion);
    }
	
	fprintf(fichero, "f:%d d:%d\n", frecuencia, duracion);
    
    signos = signos + 1;
    
    if(signos > 10)
    {
        printf("\n");
        return 1;
    }
    else { return 0; }
	
	
}

void finalizaGrabacion()
{
	fclose(fichero);
}

void main()
{
    int opcion;
    
    opcion = -1;
    
    srand(time(0));
    
    while(opcion != 0)
    {
       
        printf("=========================\n");        
        printf(" Mensaje en codigo morse\n");
        printf("=========================\n");        
        printf("1 - Reproducir mensaje\n");
		printf("2 - Grabar mensaje\n");
        printf("0 - Salir\n");
        
        scanf("%d", &opcion);

        if(opcion == 1)
        {
            int finMensaje;
            
            finMensaje = 0;
            
            iniciaReproduccion();
            
            while(finMensaje == 0)
            {
                finMensaje = reproduceSigno();
            }
            
            finalizaReproduccion();
            
        }
		else if(opcion == 2)
		{
			int finMensaje;
            
            finMensaje = 0;
            
            iniciaGrabacion();
            
            while(finMensaje == 0)
            {
                finMensaje = reproduceGrabacion();
            }
            
            finalizaGrabacion();
		}
        
    }

}